License
=======

Copyright (c) 2009, 2014 Mountainminds GmbH & Co. KG and Contributors

The JaCoCo Java Code Coverage Library and all included documentation is made
available by Mountainminds GmbH & Co. KG, Munich. Except indicated below, the
Content is provided to you under the terms and conditions of the Eclipse Public
License Version 1.0 ("EPL"). A copy of the EPL is available at
[http://www.eclipse.org/legal/epl-v10.html](http://www.eclipse.org/legal/epl-v10.html).

Please visit
[http://www.eclemma.org/jacoco/trunk/doc/license.html](http://www.eclemma.org/jacoco/trunk/doc/license.html)
for the complete license information including third party licenses and trademarks.
